---
tags:
  - CS
  - Assignment
---
#### Assignment Introduction
All of us use algorithms in our daily lives, but we rarely think about it. Most algorithms we encounter outside CS contexts are quite simple because they can be. However, even in these cases, we can still consider whether the "informal" algorithms we use can be improved!

**Assignment Goal**:
	Identify an example of an algorithm that you have used in a non-CS context. Describe the problem that you solved, the algorithm that you used, and pay special attention to the input size. What would it look like to "double the input size" for this problem? Based on the attributes that we have discussed for what makes a "good" algorithm, is the algorithm that you used good? Refer to each relevant attribute specifically.

****
I would say an example of an algorithm I use would be priority sorting. This is the method I use to determine the order in which tasks should be completed from homework to chores like the dishes or laundry. This is a very important algorithm for day to day life as it helps prevent forgetting things that need to be done and getting overwhelmed. The goal of the process is to sort to-dos into a list based on priority and due-date to ensure the completion of each task. The outline of the process is as outlined below:
1) Identify time frame
2) Identify the tasks within that time frame
3) Identify task due dates
4) Identify the task weight (What happens if this doesn't get done on time?)
5) Prioritize the tasks by the weight first and due date second
6) Rewrite the list in order of the newly established priority

The nice thing about this informal algorithm is that it scales relatively well on multiple fronts. For example, I typically priority sort when I have at least 5 things to do within a timeframe (which is usually a week). If I have an extremely high volume of things to do within a week, I shorten the timeframe to something like 3 days and/or remove non-priorities from the list main list. This way I can focus on the important tasks first and look at a much smaller set of things to do.

Based on the topics discussed in our [[Intro to Algorithms]] class session, this informal algorithm is good because it meets the criteria of being a good algorithm; It is repeatable/reusable, achieves the specified goal accurately, is able to be understood and analyzed, it is efficient, is elegant, and non-destructive.